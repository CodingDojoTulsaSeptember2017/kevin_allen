from flask import Flask, render_template, request, redirect
app = Flask(__name__)
# our index route will handle rendering our form
@app.route('/')
def index():
  return render_template("index.html")
# this route will handle our form submission

@app.route('/surveyresults', methods=['POST'])
def surveryreslts():
    name = request.form['name']
    loc  = request.form['location']
    lang = request.form['favlang']
    comment = request.form['comment']
    # print (request.form)

    return render_template("surveyresults.html", name=name, location=loc, lang=lang, comment=comment)


    return redirect('/')
app.run(debug=True) # run our server
